import bpy

class VISUALDATA_UL_List(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index): # We could write some code to decide which icon to use here... 
        custom_icon = 'OBJECT_DATAMODE' 

        if self.layout_type in {'DEFAULT', 'COMPACT'}: 
            layout.label(text=item.name, icon = custom_icon) 
        elif self.layout_type in {'GRID'}: 
            layout.alignment = 'CENTER' 
            layout.label(text=item.name, icon = custom_icon)


class HOOLICONBUILDER_PT_Panel(bpy.types.Panel):
    bl_label = "Icon Builder"
    bl_idname = "HOOLICONBUILDER_PT_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Hooligans"

    def draw(self, context):
        layout = self.layout.column()
        scene = context.scene
        icon_builder_tool = scene.icon_builder

        row = layout.row()
        row.prop(icon_builder_tool, "root_file_path")
        row = layout.row()
        row.operator("scene.loadgoonmodels")
        row = layout.row()
        row.operator("scene.loadgoonvisualdata")

        row = layout.row()
        row.template_list("VISUALDATA_UL_List", "The_List", scene,
                          "goon_visual_data_list", scene, "goon_visual_data_index")

        row = layout.row()
        row.operator("scene.assemblesinglegoon")
        row = layout.row()
        row.label(text = "Rendering")
        row = layout.row()
        row.operator("scene.savecameraposition")
        row = layout.row()
        row.operator("scene.setcameraposition")
        row = layout.row()
        row.operator("scene.rendericons")

