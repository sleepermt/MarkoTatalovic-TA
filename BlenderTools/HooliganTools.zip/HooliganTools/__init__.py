# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "IconBuilder",
    "author" : "Fuxna",
    "description" : "",
    "blender" : (2, 80, 0),
    "version" : (0, 0, 1),
    "location" : "",
    "warning" : "",
    "category" : "Generic"
}


import bpy, pip
import sys
#pip.main(['install', 'pyyaml', '--user'])
#pip.main(['install', 'pillow', '--user'])
       
packages_path = "C:\\Users\\Admin\\AppData\\Roaming\\Python\\Python39\\site-packages"
sys.path.insert(0, packages_path )


class IconBuilderSettings(bpy.types.PropertyGroup):
    root_file_path: bpy.props.StringProperty(name="Hooligans Project Path",
                                        description="Path to Json Mappings",
                                        default="C:/hooligans/",
                                        maxlen=1024,
 
                                        subtype="FILE_PATH")

class VisualDataCollection(bpy.types.PropertyGroup):
    goon_visual_data: bpy.props.StringProperty(name="Name", description="A name for this item", default="Untitled")

from .ui import HOOLICONBUILDER_PT_Panel, VISUALDATA_UL_List
from .operators import LoadGoonModels, LoadGoonVisualData, AssembleSingleGoon, SaveCameraPosition, SetCameraPosition, RenderIcons


def register():
    from bpy.utils import register_class
    register_class(HOOLICONBUILDER_PT_Panel)
    register_class(IconBuilderSettings)
    register_class(VisualDataCollection)
    register_class(LoadGoonVisualData)
    register_class(VISUALDATA_UL_List)
    register_class(LoadGoonModels)
    register_class(AssembleSingleGoon)
    register_class(SaveCameraPosition)
    register_class(SetCameraPosition)
    register_class(RenderIcons)
    bpy.types.Scene.icon_builder = bpy.props.PointerProperty(type=IconBuilderSettings)
    bpy.types.Scene.goon_visual_data_list = bpy.props.CollectionProperty(type=VisualDataCollection)
    bpy.types.Scene.goon_visual_data_index = bpy.props.IntProperty(name = "Visual Data Index", default = 0)
    bpy.types.Scene.brawler_camera_position = bpy.props.FloatVectorProperty(name = "Brawler Camera Position", default = (0, 0, 0), subtype = 'XYZ')
    bpy.types.Scene.manager_camera_position = bpy.props.FloatVectorProperty(name = "Manager Camera Position", default = (0, 0, 0), subtype = 'XYZ')
    bpy.types.Scene.schemer_camera_position = bpy.props.FloatVectorProperty(name = "Schemer Camera Position", default = (0, 0, 0), subtype = 'XYZ')
    
def unregister():
    from bpy.utils import unregister_class
    unregister_class(HOOLICONBUILDER_PT_Panel)
    unregister_class(IconBuilderSettings)
    unregister_class(VisualDataCollection)
    unregister_class(LoadGoonVisualData)
    unregister_class(VISUALDATA_UL_List)
    unregister_class(LoadGoonModels)
    unregister_class(AssembleSingleGoon)
    unregister_class(SaveCameraPosition)
    unregister_class(SetCameraPosition)
    unregister_class(RenderIcons)
    del bpy.types.Scene.icon_builder
    del bpy.types.Scene.goon_visual_data_list
    del bpy.types.Scene.goon_visual_data_index
    del bpy.types.Scene.brawler_camera_position
    del bpy.types.Scene.manager_camera_position
    del bpy.types.Scene.schemer_camera_position
#endregion