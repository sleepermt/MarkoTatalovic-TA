import bpy
import os
from .defines import GUID_TO_FILE_MAPPING_FILEPATH, GOON_VISUAL_DATA_PATH, PRESET_BODY_MATERIAL, PRESET_EYES_MATERIAL, GOON_MATERIALS_DATA_PATH

def GetModulePath():
    import addon_utils
    return os.path.dirname([mod.__file__ for mod in addon_utils.modules() if mod.bl_info.get("name") == "IconBuilder"][0])

def GetGUIDToFileMappingFilepath(scene):
    return os.path.join(scene.icon_builder.root_file_path, GUID_TO_FILE_MAPPING_FILEPATH)

def GetVisualGoonDataFilepath(scene):
    return os.path.join(scene.icon_builder.root_file_path, GOON_VISUAL_DATA_PATH)

def GetMaterialFilepath(scene):
    return os.path.join(scene.icon_builder.root_file_path, GOON_MATERIALS_DATA_PATH)

def GetCollectionInViewLayer(layer_name, collection_name):
    found = None
    if (layer_name.name == collection_name):
        return layer_name
    for layer in layer_name.children:
        found = GetCollectionInViewLayer(layer, collection_name)
        if found:
            return found

def GetCollection(collection_name, context):
    """Returns collection by name, if doesn't exist creates new one

    Args:
        collection_name (string): Name of collection
        context (context): Operator context

    Returns:
        bpy.data.collection: bpy.data.collection
    """
    collection = bpy.data.collections.get(collection_name)  
    if collection == None:
        collection = bpy.context.blend_data.collections.new(name=collection_name)
        context.collection.children.link(collection)

    return collection

def ChangeActiveCollection(collection, context):
    """Changes Active Collection in outliner

    Args:
        collection (bpy.data.collection): Collection to make active
        context (bpy.context): Operator context
    """
    view_layer_collections = context.view_layer.layer_collection
    layer_collection = GetCollectionInViewLayer(view_layer_collections, collection.name)
    context.view_layer.active_layer_collection = layer_collection

def ClearAllMaterials():
    for material in bpy.data.materials:
        if material.name == PRESET_BODY_MATERIAL or material.name == PRESET_EYES_MATERIAL:
            continue
        if material.get('GUID') == None:
           bpy.data.materials.remove(material, do_unlink=True)

def ClearAllTextures():
    for texture in bpy.data.images:
        if texture.get('GUID') == None:
            bpy.data.images.remove(texture)

def ObjectWithGuidDoesExist(guid):
    """Check if object with given guid exists in scene

    Args:
        guid (string): Object Guid to check for

    Returns:
        bool: True if exists otherwise false
    """
    for obj in bpy.data.objects:
        try:
            if obj["GUID"] == guid:
                return True
        except:
            continue
    return False

def MaterialWithGuidDoesExist(guid):
    """Check if material with given guid exists in scene

    Args:
        guid (string): Object Guid to check for

    Returns:
        bool: True if exists otherwise false
    """

    for mat in bpy.data.materials:
        try:
            if mat["GUID"] == guid:
                return True
        except:
            continue
    return False

def GetSingleGuidFromYaml(yaml_file, fields_to_read):
    read_from = yaml_file
    for field in fields_to_read:
        if type(read_from) == type([]): #if fields are list read the list and return matching field
            for f in read_from:
                if f.get(field) != None:
                    read_from = f.get(field)
                    break
            continue
        read_from = read_from.get(field)
        
    
    return read_from
    
def GetGuidsFromYaml(yaml_path, list_of_fields_to_read, offset):
    """Returns all Guids from yaml file

    Args:
        yaml_path (string): Path to yaml file
        list_of_fields_to_read (_type_): List of yaml fields to read from

    Returns:
        String list: Returns list of guids
    """
    guids = []

    import yaml
    with open (yaml_path, 'r') as f:
        yaml_file = yaml.load(f.read()[offset:], Loader=yaml.SafeLoader)
        #print(yaml_file['Material']['m_SavedProperties']['m_TexEnvs'][11])

        for fields_to_read in list_of_fields_to_read:
            guid = GetSingleGuidFromYaml(yaml_file, fields_to_read)
            guids.append(guid)
    return guids

def appendPresetMaterial():
    module_path = GetModulePath()
    with bpy.data.libraries.load(module_path + '/pressets.blend', link=False) as (data_from, data_to):
        data_to.materials = data_from.materials

