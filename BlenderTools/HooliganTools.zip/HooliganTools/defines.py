from enum import Enum
import enum

GUID_TO_FILE_MAPPING_FILEPATH = "Assets/Editor/GuidToFilePathMapping.json"
GOON_VISUAL_DATA_PATH = "Assets/Scripts/Data/VisualData/GoonVisualData"
GOON_MATERIALS_DATA_PATH = "Assets/Art/3D/Materials/SkinAndHair"
PRESET_BODY_MATERIAL = 'PresetBodyMaterial'
PRESET_EYES_MATERIAL = 'PresetEyesMaterial'
YAML_GOON_VISUAL_DATA_OFFSET = 61
YAML_MATERIAL_DATA_OFFSET = 60

class GoonTypes(Enum):
    BRAWLER = 'Brawler'
    MANAGER = 'Manager'
    SCHEMER = 'Schemer'

class BodyParts(Enum):
    BODY = 'body'
    HAIR = 'hair'
    EAR  = 'ear'
    EYES = 'eyes'
    NOSE = 'nose'
    EYEBROWS = 'eyebrows'
    BEARD = 'beard'
    
class MaterialTypes(Enum):
    BRAWLER_BODY = 'brawlerBody'
    MANAGER_BODY = 'managerBody'
    SCHEMER_BODY = 'schemerBody'
    HAIR_BEARD   = 'hairBeard'
    EYES         = 'eyes'