import bpy
import os

from .utils import GetCollection, ChangeActiveCollection, GetMaterialFilepath, ObjectWithGuidDoesExist, ClearAllMaterials, GetGUIDToFileMappingFilepath, \
GetVisualGoonDataFilepath, GetGuidsFromYaml, appendPresetMaterial, MaterialWithGuidDoesExist, GetMaterialFilepath, ClearAllTextures
from .defines import PRESET_BODY_MATERIAL, PRESET_EYES_MATERIAL, YAML_GOON_VISUAL_DATA_OFFSET, YAML_MATERIAL_DATA_OFFSET, GoonTypes, BodyParts, MaterialTypes

class LoadGoonModels(bpy.types.Operator):
    bl_idname = "scene.loadgoonmodels"
    bl_label  = "Load Goon Models"

    @classmethod
    def poll(cls, context):
        return  context.scene.icon_builder.root_file_path != ""
        
    def execute(self, context):
        import json
        scene = context.scene

        all_goons_collection = GetCollection('Goons', context)
        ChangeActiveCollection(all_goons_collection, context)
        
        mappings_filepath = GetGUIDToFileMappingFilepath(scene) 

        

        with open(mappings_filepath, "r") as mappings_file:
            print("LOADING GOONS MODEL FROM JSON MAPPING")

            mappings_json = json.load(mappings_file)
            
            for goon_type in GoonTypes:
                goon_collection = GetCollection(goon_type.value, context)
                ChangeActiveCollection(goon_collection, context)

                goon_mapping = mappings_json[goon_type.value.lower() + 'GoonMapping']
                for body_part in BodyParts:
                    for i, fbx_path in enumerate(goon_mapping[body_part.value + 'Filepaths']):
                        if (ObjectWithGuidDoesExist(goon_mapping[body_part.value + 'Guids'][i])):
                            continue
                        path = scene.icon_builder.root_file_path + fbx_path
                        bpy.ops.import_scene.fbx( filepath = path)
                        imported_objects = context.selected_objects
                        for obj in imported_objects:
                            if obj.type == 'ARMATURE' or obj.type == 'EMPTY':
                                bpy.data.objects.remove(bpy.data.objects[obj.name], do_unlink = True) #delete rig or empty
                            else:
                                obj.name = fbx_path.split('/')[-1] 
                                obj["GUID"] = goon_mapping[body_part.value + 'Guids'][i]

                ChangeActiveCollection(all_goons_collection, context)
            print("FINISHED LOADING GOON MODELS")

            print("LOADING MATERIALS")
            if PRESET_BODY_MATERIAL not in bpy.data.materials:
                appendPresetMaterial()

            preset_body_material = bpy.data.materials[PRESET_BODY_MATERIAL]
            preset_eye_Material  = bpy.data.materials[PRESET_EYES_MATERIAL]

            for material_type in MaterialTypes:
                material_mapping = mappings_json[material_type.value + 'MaterialMapping']
                for i, material_filepath in enumerate(material_mapping['materialFilepaths']):
                    if (MaterialWithGuidDoesExist(material_mapping['materialGuids'][i])):
                            continue
                    new_material = preset_body_material.copy()
                    new_material.name = material_filepath.split("/")[-1]
                    new_material['GUID'] = material_mapping['materialGuids'][i]

            
            texture_mapping = mappings_json['textureMapping']
            for i, texture_filepath in enumerate(texture_mapping['textureFilepaths']):
                texture = bpy.data.images.load(scene.icon_builder.root_file_path + texture_filepath, check_existing = True)
                texture['GUID'] = texture_mapping['textureGuids'][i]


            
        material_list = [material for material in bpy.data.materials if material.get('GUID') != None]
        texture_list  = [texture for texture in bpy.data.images if texture.get('GUID') != None]

        ClearAllTextures()

        material_fields = [
            ['Material', 'm_SavedProperties', 'm_TexEnvs', '_NormalAoCurvature', 'm_Texture', 'guid'],
            ['Material', 'm_SavedProperties', 'm_Colors', '_PrimaryColor']
        ]

        def sRGB(x):
            return pow(x, 2.2)
            if (x <= 0.00031308):
                return 12.92 * x
            else:
                return 1.055*pow(x,(1.0 / 2.4) ) - 0.055
        

        for material in material_list:
            if material.name == "MT_ALL_Eyes.mat":
                continue
            guids = GetGuidsFromYaml(os.path.join(GetMaterialFilepath(scene), material.name), material_fields, YAML_MATERIAL_DATA_OFFSET)
            color = guids[1]
            color_node = material.node_tree.nodes.get('RGB')
            color_node.outputs[0].default_value = (sRGB(color['r']), sRGB(color['g']), sRGB(color['b']), 1)
            for texture in texture_list:
                if guids[0] == texture.get('GUID'):
                    meterial_NCAO_node = material.node_tree.nodes.get('Composite')
                    meterial_NCAO_node.image = texture
                    meterial_NCAO_node.image.colorspace_settings.name = 'Non-Color'


        ClearAllMaterials()
        print("FINISHED LOADING MATERIALS")

        return {'FINISHED'}

class LoadGoonVisualData(bpy.types.Operator):
    bl_idname = "scene.loadgoonvisualdata"
    bl_label  = "Load Goon Visual Data"

    def execute(self, context):
        import os
        import re

        scene = context.scene

        visual_goon_data = [f for f in os.listdir(GetVisualGoonDataFilepath(scene)) if f.endswith(".asset")]
        visual_goon_data = sorted(visual_goon_data, key=lambda f: int(re.findall(r'\d+', f)[0]))

        context.scene.goon_visual_data_list.clear()
        for f in visual_goon_data:
            visual_data = context.scene.goon_visual_data_list.add()
            visual_data.name = f

        return {"FINISHED"}

def AssembleSingeGoon(context, index):
    scene = context.scene
    selected_visual_goon_data = scene.goon_visual_data_list[index]

    goon_parts_fields = [
        ['MonoBehaviour','body','m_AssetGUID'],
        ['MonoBehaviour','hair','m_AssetGUID'],
        ['MonoBehaviour','nose','m_AssetGUID'],
        ['MonoBehaviour','eyebrows','m_AssetGUID'],
        ['MonoBehaviour','eyes','m_AssetGUID'],
        ['MonoBehaviour','ears','m_AssetGUID'],
        ['MonoBehaviour','beard','m_AssetGUID']
    ]

    goon_parts_guids = GetGuidsFromYaml(os.path.join(GetVisualGoonDataFilepath(scene), selected_visual_goon_data.name), goon_parts_fields, YAML_GOON_VISUAL_DATA_OFFSET)

    body_parts = [] 
    accessories = []   
    for obj in bpy.data.objects:
        try:
            if obj['GUID'] in goon_parts_guids:
                obj.hide_viewport = False
                obj.hide_render   = False
                if  'Beard'  in obj.name or 'Eyebrows' in obj.name or 'Hair' in obj.name:
                    accessories.append(obj)
                else:
                    body_parts.append(obj)
            else:
                obj.hide_viewport = True
                obj.hide_render   = True
        except:
            continue
    
    goon_material_fields = [
        ['MonoBehaviour','bodyMaterial','m_AssetGUID'],
        ['MonoBehaviour','hairMaterial','m_AssetGUID'],
        ['MonoBehaviour','beardMaterial','m_AssetGUID'],
    ]

    goon_material_guids = GetGuidsFromYaml(os.path.join(GetVisualGoonDataFilepath(scene), selected_visual_goon_data.name), goon_material_fields, YAML_GOON_VISUAL_DATA_OFFSET)
    body_material = [material for material in bpy.data.materials if material.get('GUID') != None and material['GUID'] in goon_material_guids[0]][0]

    hair_material = None
    beard_material = None

    for material in bpy.data.materials:
        if material.get('GUID') != None:
            if material['GUID'] == goon_material_guids[1]:
                hair_material = material
                        
    for material in bpy.data.materials:
        if material.get('GUID') != None:
            if material['GUID'] == goon_material_guids[1]:
                beard_material = material


    for part in body_parts:
        for i in range(len(part.material_slots)):
            bpy.ops.object.material_slot_remove({'object': part})
        if len([s for s in part.material_slots if s.material]) == 0:
            part.data.materials.append(body_material)              
        else:
            part.data.materials[0] = body_material
            
    for part in accessories:
        if 'Hair' in part.name or 'Eyebrows' in part.name:
            for i in range(len(part.material_slots)):
                bpy.ops.object.material_slot_remove({'object': part})
            if len([s for s in part.material_slots if s.material]) == 0:
                part.data.materials.append(hair_material)              
            else:
                part.data.materials[0] = hair_material
        else:
            for i in range(len(part.material_slots)):
                bpy.ops.object.material_slot_remove({'object': part})
            if len([s for s in part.material_slots if s.material]) == 0:
                part.data.materials.append(beard_material)              
            else:
                part.data.materials[0] = beard_material




class AssembleSingleGoon(bpy.types.Operator):
    bl_idname = "scene.assemblesinglegoon"
    bl_label  = "Assemble Single Goon"

    def execute(self, context):
        scene = context.scene
        AssembleSingeGoon(context, scene.goon_visual_data_index)
        return {'FINISHED'}

class SaveCameraPosition(bpy.types.Operator):
    bl_idname = "scene.savecameraposition"
    bl_label  = "Save Camera Position"

    preset_enum : bpy.props.EnumProperty(
        name = "",
        description = "Select Goon Type",
        items = [
            ('OP1', "Brawler", ""),
            ('OP2', "Manager", ""),
            ('OP3', "Schemer", "")
        ]
    )

    @classmethod
    def poll(cls, context):
        return context.active_object != None and context.active_object.type == 'CAMERA'

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)

    def execute(self, context):
        if self.preset_enum == 'OP1':
            context.scene.brawler_camera_position = context.active_object.location
        elif self.preset_enum == 'OP2':
            context.scene.manager_camera_position = context.active_object.location
        elif self.preset_enum == 'OP3':
            context.scene.schemer_camera_position = context.active_object.location

        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "preset_enum")

def setCameraPosition(context):
    names =[ob.name for ob in context.view_layer.objects if ob.visible_get()]
    camera = context.scene.camera
    if "MD_Manager.fbx" in names:
        camera.location = context.scene.manager_camera_position
    elif "MD_Schemer.fbx" in names:
        camera.location = context.scene.schemer_camera_position
    elif "MD_Brawler.fbx" in names:
        camera.location = context.scene.brawler_camera_position

class SetCameraPosition(bpy.types.Operator):
    bl_idname = "scene.setcameraposition"
    bl_label = "Set Camera Position"

    def execute(self, context):
        setCameraPosition(context)
        return {'FINISHED'}

def createAtlas(context, files, atlas_name, atlas_size_x, atlas_size_y):
    from PIL import Image

    x = atlas_size_x
    y = atlas_size_y

    image_list = []
    import re
    
    for filename in files:
        im = Image.open(filename + ".png")
        image_list.append(im)

    new_image = Image.new('RGBA', (x, y))

    offset_x = 0
    offset_y = 0

    for im in image_list:
        if offset_x >= x:
            offset_x = 0
            offset_y += int(y/8)
        
        new_image.paste(im, (offset_x, offset_y))
        offset_x += int(x/8)
    
    #atlas_save_file_path = '{0}\{1}.png'.format(atlas_output_dir, atlas_name)
    atlas_save_file_path = 'C:/temp/asd.png'
    new_image.save(atlas_save_file_path) 
    # if context.scene.hooligans_tool.show_atlas_bool:
    new_image.show()
 
  


class RenderIcons(bpy.types.Operator):
    bl_idname = "scene.rendericons"
    bl_label  = "Render Icons"

    @classmethod
    def poll(cls, context):
        return len(context.scene.goon_visual_data_list) > 0

    def execute(sefl, context):
        appendPresetMaterial()
        
        scene = context.scene
        files = []
        for i, vd in enumerate(scene.goon_visual_data_list):
            AssembleSingeGoon(context, i)
            setCameraPosition(context)

            scene.render.filepath = 'C:/temp/' + vd.name.split(".")[0]
            files.append(scene.render.filepath)
            bpy.ops.render.render(write_still = 1)
        
        createAtlas(context, files, 'aaa', 2048, 2048)
        return {'FINISHED'}