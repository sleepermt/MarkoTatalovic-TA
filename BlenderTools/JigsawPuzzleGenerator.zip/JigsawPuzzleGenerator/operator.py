import bpy
import bmesh
import math
from mathutils import Vector, Matrix
from array import array
from random import randint


class Jigsaw_Puzzle_Generator_Operator(bpy.types.Operator):
    bl_idname = "object.jigsaw_puzzle_generator_operator"
    bl_label = "jigsaw puzzle generator"
    bl_options = {'REGISTER', 'UNDO'}
    
    width : bpy.props.FloatProperty(name="Width", default = 6.0)
    heigth : bpy.props.FloatProperty(name="Heigth", default = 4.0)
    no_of_collumns : bpy.props.IntProperty(name='Number of Collumns', default = 6)
    no_of_rows : bpy.props.IntProperty(name='Number of Rows', default = 4)
    depth: bpy.props.FloatProperty(name="Depth", default = 0.01)
    bevel_offset: bpy.props.FloatProperty(name="Bevel Offset", default = 0.020752)
    bevel_profile: bpy.props.FloatProperty(name="Bevel Profile", default = 0.75)
    bevel_segments: bpy.props.IntProperty(name="Bevel Segments", default = 1)
    
    @classmethod
    def poll(cls, context):
        return context.area.type == 'VIEW_3D'
    
    def execute(self, context):

        verts =[(-1.,          1.,          0.        ),
                (-0.87119716,  0.99367046,  0.        ),
                (-0.74880296,  0.98840904,  0.        ),
                (-0.64146787,  0.9842343,   0.        ),
                (-0.53391314,  0.9857724,   0.        ),
                (-0.44767162,  0.98884845,  0.        ),
                (-0.3612104,   0.9976374,   0.        ),
                (-0.2733246,   1.0177789,   0.        ),
                (-0.21649624,  1.0582894,   0.        ),
                (-0.1878479,   1.1040328,   0.        ),
                (-0.17977002,  1.1559093,   0.        ),
                (-0.19008389,  1.2162163,   0.        ),
                (-0.21855637,  1.2842677,   0.        ),
                (-0.25075477,  1.3568995,   0.        ),
                (-0.26477537,  1.4310423,   0.        ),
                (-0.24916735,  1.5031676,   0.        ),
                (-0.20214076,  1.5648158,   0.        ),
                (-0.13273782,  1.6064997,   0.        ),
                (-0.05154829,  1.6274416,   0.        ),
                ( 0.03516326,  1.6287336,   0.        ),
                ( 0.11870265,  1.6087973,   0.        ),
                ( 0.18763083,  1.567282,    0.        ),
                ( 0.23203647,  1.5082333,   0.        ),
                ( 0.24696904,  1.4392693,   0.        ),
                ( 0.23492062,  1.3690416,   0.        ),
                ( 0.20645782,  1.3018358,   0.        ),
                ( 0.17645904,  1.2343096,   0.        ),
                ( 0.16075215,  1.1647943,   0.        ),
                ( 0.16970967,  1.101342,    0.        ),
                ( 0.20616984,  1.050365,    0.        ),
                ( 0.2709201,   1.0110209,   0.        ),
                ( 0.35796365,  0.99128413,  0.        ),
                ( 0.46579692,  0.98937804,  0.        ),
                ( 0.5755678,   0.9905464,   0.        ),
                ( 0.69527656,  0.99337155,  0.        ),
                ( 0.8368461,   0.9965606,   0.        ),
                ( 1.,          1.,          0.        )]

        
        piece_size_x = self.width  / self.no_of_collumns
        piece_size_y = self.heigth / self.no_of_rows

        top_left_corner = Vector((0 - self.width/2 + piece_size_x/2, 0 + self.heigth/2 - piece_size_y/2, 0.0))

        scale_factor_x = piece_size_x / 2 
        scale_factor_y = piece_size_y / 2
        scale_factor = Vector((scale_factor_x, scale_factor_y, 1.0))

        # 0 - convex
        # 1 - concave
        # 2 - flat

        pieces = []
        idx = -1

        for row in range(0, self.no_of_rows): 
            
            for col in range(0, self.no_of_collumns):
                top, left = 2, 2
                bottom, right = randint(0, 1), randint(0, 1)

                #First Piece
                if idx == -1:
                    pieces.append({'top'    : top, 
                                   'bottom' : bottom, 
                                   'left'   : left,
                                   'right'  : right})

                    idx += 1
                    
                else:
                    #TOP:
                    if row == 0:
                        top = 2
                    # if top neighbor's bottom edge is convex
                    elif pieces[idx - self.no_of_collumns + 1]['bottom'] < 1:
                        top = 1
                    else:
                        top = 0

                    #BOTTOM:
                    #if piece is in the last row
                    if (row + 1) == self.no_of_rows:
                        bottom = 2
                        
                    #LEFT:
                    # if its first piece in row
                    if col == 0:
                        left = 2
                    # if right neightbor's right side is convex
                    elif pieces[idx]['right'] < 1:
                        left = 1
                    else:
                        left = 0

                    #RIGHT
                    # if its last piece in a row
                    if (col + 1) == self.no_of_collumns:
                        right = 2
                    
                    pieces.append({'top'    : top, 
                                   'bottom' : bottom, 
                                   'left'   : left,
                                   'right'  : right})
            
                    idx += 1
            
        
        # Geo
        
        bm = bmesh.new()
        current_row = -1
        idx = 0
 
        for p in pieces:
            temp_bm = bmesh.new()

            # TOP:
            if p['top'] == 2:
                temp_bm.verts.new((-1.0, 1.0,  0.0))
                temp_bm.verts.new(( 1.0, 1.0,  0.0))

            elif p['top'] == 1:
                for v in reversed(verts):
                    temp_bm.verts.new(v)
            
                bmesh.ops.rotate(
                    temp_bm,
                    verts = temp_bm.verts[-37:],
                    cent = ( 0.0,  1.0, 0.0),
                    matrix = Matrix.Rotation(math.radians(180.0), 3, 'Z'))

            else:
                for v in verts:
                    temp_bm.verts.new(v)

            # RIGHT:
            if p['right'] == 2:
                temp_bm.verts.new(( 1.0, 1.0,  0.0))
                temp_bm.verts.new(( 1.0, -1.0,  0.0))
            
            elif p['right'] == 1:
                for v in reversed(verts):
                    temp_bm.verts.new(v)
        
                bmesh.ops.rotate(
                    temp_bm,
                    verts = temp_bm.verts[-37:],
                    cent = ( 1.0,  1.0, 0.0),
                    matrix = Matrix.Rotation(math.radians(90.0), 3, 'Z'))

            else: 
                for v in verts:
                    temp_bm.verts.new(v)
        
                bmesh.ops.rotate(
                    temp_bm,
                    verts = temp_bm.verts[-37:],
                    cent = ( 1.0,  1.0, 0.0),
                    matrix = Matrix.Rotation(math.radians(-90.0), 3, 'Z'))
                    
                bmesh.ops.translate(
                    temp_bm,
                    verts= temp_bm.verts[-37:],
                    vec=(0.0, -2.0, 0.0))

            # BOTTOM:
            if p['bottom'] == 2:
                temp_bm.verts.new((-1.0, -1.0,  0.0))
            
            elif p['bottom'] == 1:
                for v in reversed(verts):
                    temp_bm.verts.new(v)

                bmesh.ops.translate(
                    temp_bm,
                    verts= temp_bm.verts[-37:],
                    vec=(0.0, -2.0, 0.0))

            else:
                for v in verts:
                    temp_bm.verts.new(v)
                
                bmesh.ops.rotate(
                    temp_bm,
                    verts = temp_bm.verts[-37:],
                    cent = ( 0.0, 0.0, 0.0),
                    matrix = Matrix.Rotation(math.radians(180.0), 3, 'Z'))

            # LEFT:
            if p['left'] == 2:
                temp_bm.verts.new(( -1.0,  1.0,  0.0))
                temp_bm.verts.new(( -1.0, -1.0,  0.0))
                current_row += 1.0

            elif p['left'] == 1:
                for v in reversed(verts):
                    temp_bm.verts.new(v)

                bmesh.ops.rotate(
                    temp_bm,
                    verts = temp_bm.verts[-37:],
                    cent = ( -1.0, 1.0, 0.0),
                    matrix = Matrix.Rotation(math.radians(-90.0), 3, 'Z'))

            else:
                for v in verts:
                    temp_bm.verts.new(v)

                bmesh.ops.rotate(
                    temp_bm,
                    verts = temp_bm.verts[-37:],
                    cent = ( -1.0, 1.0, 0.0),
                    matrix = Matrix.Rotation(math.radians(90.0), 3, 'Z'))

                bmesh.ops.translate(
                    temp_bm,
                    verts= temp_bm.verts[-37:],
                    vec=(0.0, -2.0, 0.0))
            

            temp_bm.verts.ensure_lookup_table()

            for i, v in enumerate(temp_bm.verts):
                if i < (len(temp_bm.verts)-1):
                    temp_bm.edges.new((temp_bm.verts[i], temp_bm.verts[i+1]))
                else:
                    break

            edges = temp_bm.edges[:]
            bmesh.ops.remove_doubles(temp_bm, verts = temp_bm.verts[:], dist = 0.01)
            bmesh.ops.contextual_create(temp_bm, geom = temp_bm.verts[:] + temp_bm.edges[:] + temp_bm.faces[:])
            
            bmesh.ops.inset_individual(temp_bm, faces = temp_bm.faces[:], thickness = 0.031593, depth = 0, use_even_offset = True, use_interpolate = True, use_relative_offset = False)
            
            temp_bm.faces.ensure_lookup_table()
            v = temp_bm.faces[0].verts

            bmesh.ops.transform(
                                temp_bm,
                                matrix = Matrix.Translation((0.0, 0.0, self.depth)),
                                verts= v,
                                space = Matrix.Translation((0.0, 0.0, 0.0))
                                )
            
            edges = [ele for ele in temp_bm.faces[0].edges if isinstance(ele, bmesh.types.BMEdge)]
            
            bmesh.ops.bevel(temp_bm, 
                            geom = temp_bm.faces[0].edges,
                            offset = self.bevel_offset, 
                            offset_type = 'OFFSET', 
                            segments = self.bevel_segments, 
                            profile = self.bevel_profile, #, vertex_only, clamp_overlap, material, 
                            loop_slide = True #, mark_seam, mark_sharp, harden_normals, face_strength_mode, miter_outer, miter_inner, spread, smoothresh, use_custom_profile, custom_profile, vmesh_method)
                            ) 
            
            if idx < self.no_of_collumns: 
                bmesh.ops.translate(
                                temp_bm,
                                verts= temp_bm.verts[:],
                                vec=Vector((2.0 * idx, -current_row * 2.0, 0.0))
                                )
            else:
                idx = 0
                bmesh.ops.translate(
                                temp_bm,
                                verts= temp_bm.verts[:],
                                vec=Vector((2.0 * idx, -current_row * 2.0, 0.0))
                                )
            idx += 1.0

            bmesh.ops.contextual_create(temp_bm, geom = temp_bm.edges[:])
            
            temp_mesh = bpy.data.meshes.new(".temp")
            temp_bm.to_mesh(temp_mesh)
            bm.from_mesh(temp_mesh)
            bpy.data.meshes.remove(temp_mesh)

        

        bmesh.ops.scale(
                    bm,
                    verts = bm.verts[:],
                    vec = scale_factor,
                    #space = Matrix.Translation((0, 0, 1))
                    
                    )

        bmesh.ops.translate(
                    bm,
                    verts= bm.verts[:],
                    vec=(top_left_corner)
                    )
        
        mesh = bpy.data.meshes.new('mesh')
        bm.to_mesh(mesh)
        bm.free()
        
        obj = bpy.data.objects.new('Jigsaw_Puzzle', mesh)

        #TODO : make sure shit still works if there are no collections, or make new collection
        collection = bpy.data.collections.get("Collection")
        collection.objects.link(obj)

        bpy.context.view_layer.objects.active = obj
        obj.select_set(True)

        return{'FINISHED'}

    
    def draw(self, context):
        layout = self.layout
        col = layout.column()

        col.prop(self, "width")
        col.prop(self, "heigth")
        col.prop(self, "no_of_collumns")
        col.prop(self, "no_of_rows")
        col.prop(self, "depth")
        col.prop(self, "bevel_offset")
        col.prop(self, "bevel_segments")
        col.prop(self, "bevel_profile")