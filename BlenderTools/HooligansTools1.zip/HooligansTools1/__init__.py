# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "HooligansTools",
    "author" : "Fuxna",
    "description" : "",
    "blender" : (2, 80, 0),
    "version" : (0, 0, 1),
    "location" : "",
    "warning" : "",
    "category" : "Generic"
}

#TODO : mutliple selected collections https://devtalk.blender.org/t/get-list-of-selected-collections-in-outliner/17276
#TODO : make zPosition render in lower res

import bpy, pip
#pip.main(['install', 'pillow', '--user'])\

import sys
packages_path = "C:\\Users\\Admin\\AppData\\Roaming\\Python\\Python39\\site-packages"
sys.path.insert(0, packages_path )

buildings_output_dir = r"C:\hooligans\Assets\Art\Sprites\Buildings"
tileSprite_output_dir = r"C:\temp"
atlas_output_dir = r"C:\temp"#hooligans\Assets\Art\Sprites\TileSprites"

sqr_root_of_2 = 1.4142135623730951
#pixelUnitSize = 0.022096873682923613

def getPixelUnitSize(op):
    PPU = 0
    if op == 'OP1':
        PPU = 48
    elif op == 'OP2':
        PPU = 64
    elif op == 'OP3':
        PPU = 96
    else:
        PPU = 128
    
    return sqr_root_of_2/PPU

def closestNumber(n, m) :
    q = int(n / m)
     
    n1 = m * q
    
    if((n * m) > 0) :
        n2 = (m * (q + 1))
    else :
        n2 = (m * (q - 1))
     
    if (abs(n - n1) < abs(n - n2)) :
        return n1
     
    return n2

def traverse_tree(t):
    yield t
    for child in t.children:
        yield from traverse_tree(child)

def renderSingleBuilding(context, collection):
    for c in traverse_tree(collection):
        c.hide_render = False
    
    camera = context.scene.camera
    camera_controller = [obj for obj in collection.objects if obj.name.startswith('CC')][0]

    x = camera_controller.dimensions.x
    y = camera_controller.dimensions.y * 0.5 
    d = max(x, y)

    pixelUnitSize = getPixelUnitSize(context.scene.hooligans_tool.ppu_enum)
    
    res_x = int(x / pixelUnitSize)
    res_y = int(y / pixelUnitSize)
    
    camera.data.ortho_scale = d
        
    bpy.context.scene.render.resolution_x = closestNumber(res_x, 4)
    bpy.context.scene.render.resolution_y = closestNumber(res_y, 4)
    print(closestNumber(res_y, 4))

    bpy.ops.render.render(write_still = 1)

def renderZ(context, collection):
    for c in traverse_tree(collection):
        c.hide_render = False

    context.scene.view_layers["View Layer"].material_override = bpy.data.materials["renderZ"]
    camera = context.scene.camera
    camera_controller = [obj for obj in collection.objects if obj.name.startswith('CC')][0]

    x = camera_controller.dimensions.x
    y = camera_controller.dimensions.y * 0.5 
    d = max(x, y)

    pixelUnitSize = getPixelUnitSize(context.scene.hooligans_tool.ppu_enum)
    
    res_x = int(x / pixelUnitSize)
    res_y = int(y / pixelUnitSize)
    
    camera.data.ortho_scale = d
        
    bpy.context.scene.render.resolution_x = closestNumber(res_x, 4)
    bpy.context.scene.render.resolution_y = closestNumber(res_y, 4)

    from mathutils import Vector

    mesh_collection = [c for c in collection.children if c.name.startswith('MeshC')][0]
    min_z = +9999
    max_z = -9999

    for obj in mesh_collection.objects:
        bbox = [obj.matrix_world @ Vector(v) for v in obj.bound_box]
        v_min_z = +9999
        v_max_z = -9999
        
        for v in bbox: 
            z = v[1]
            if z < v_min_z:
                v_min_z = z
            if z > v_max_z:
                v_max_z = z

        if v_min_z < min_z:
            min_z = v_min_z
        if v_max_z > max_z:
            max_z = v_max_z

    bpy.data.materials["renderZ"].node_tree.nodes["Map Range"].inputs[1].default_value = min_z
    bpy.data.materials["renderZ"].node_tree.nodes["Map Range"].inputs[2].default_value = max_z

    context.scene.display_settings.display_device = 'XYZ'
    bpy.ops.render.render(write_still = 1)

    context.scene.view_layers["View Layer"].material_override = None
    context.scene.display_settings.display_device = 'sRGB'



class RenderZOperator(bpy.types.Operator):
    bl_idname = "object.renderz"
    bl_label = "RenderZ"

    @classmethod
    def poll(cls, context):
        building_collection = context.collection
        
        if (building_collection.name.startswith("Town")):
            return False

        try:
            parent_collection = [c for c in bpy.data.collections if c.user_of_id(building_collection)][0]
        except:
            return False
        return parent_collection.name.startswith("Active") or parent_collection.name.startswith("Neutral")

    def execute(self, context):
        building_collection = context.collection

        parent_collection = [c for c in bpy.data.collections if c.user_of_id(building_collection)][0]
        root_collection = [c for c in bpy.data.collections if c.user_of_id(parent_collection)][0]

        for c in bpy.data.collections:
            c.hide_render = True
       
        parent_collection.hide_render = False
        root_collection.hide_render = False

        parent_name = ""
        if (parent_collection.name.startswith("Active")):
            parent_name = "Active"
        else:
            parent_name = "Neutral"

        
        bpy.context.scene.render.filepath = '{0}\{1}\{2}\SZ_{3}'.format(buildings_output_dir, root_collection.name, parent_name, building_collection.name)
        renderZ(context, building_collection)
        from PIL import Image, ImageFilter
        im = Image.open(bpy.context.scene.render.filepath + ".png")
        im = im.filter(ImageFilter.GaussianBlur(radius=2))
        im.save(bpy.context.scene.render.filepath + ".png")
        
        return {'FINISHED'}



class SetCameraBoundsOperator(bpy.types.Operator):
    bl_idname = "object.setcamerabounds"
    bl_label = "Set Camera Bounds"

    @classmethod
    def poll(cls, context):
        
        return  context.active_object is not None and context.active_object.name.startswith("CC")

    def execute(self, context):
        camera = context.scene.camera
        camera_controller = context.active_object
        x = camera_controller.dimensions.x
        y = camera_controller.dimensions.y * 0.5 
        d = max(x, y)

        pixelUnitSize = getPixelUnitSize(context.scene.hooligans_tool.ppu_enum)
        
        res_x = int(x / pixelUnitSize)
        res_y = int(y / pixelUnitSize)
        
        camera.data.ortho_scale = d
         
        bpy.context.scene.render.resolution_x = closestNumber(res_x, 4)
        bpy.context.scene.render.resolution_y = closestNumber(res_y, 4)
        
        return {'FINISHED'}

class RenderSingleBuildingOperator(bpy.types.Operator):
    bl_idname = "object.rendersinglebuilding"
    bl_label = "Render Single Building"

    @classmethod
    def poll(cls, context):
        building_collection = context.collection
        
        if (building_collection.name.startswith("Town")):
            return False

        try:
            parent_collection = [c for c in bpy.data.collections if c.user_of_id(building_collection)][0]
        except:
            return False
        return parent_collection.name.startswith("Active") or parent_collection.name.startswith("Neutral")

    def execute(self, context):
        building_collection = context.collection

        parent_collection = [c for c in bpy.data.collections if c.user_of_id(building_collection)][0]
        root_collection = [c for c in bpy.data.collections if c.user_of_id(parent_collection)][0]

       
        for c in bpy.data.collections:
            c.hide_render = True
       
        parent_collection.hide_render = False
        root_collection.hide_render = False

        parent_name = ""
        if (parent_collection.name.startswith("Active")):
            parent_name = "Active"
        else:
            parent_name = "Neutral"

        bpy.context.scene.render.filepath = '{0}\{1}\{2}\S_{3}'.format(buildings_output_dir, root_collection.name, parent_name, building_collection.name)
        renderSingleBuilding(context, building_collection)

        if context.scene.hooligans_tool.render_z_bool:
            bpy.context.scene.render.filepath = '{0}\{1}\{2}\SZ_{3}'.format(buildings_output_dir, root_collection.name, parent_name, building_collection.name)
            renderZ(context, building_collection)
            from PIL import Image, ImageFilter
            im = Image.open(bpy.context.scene.render.filepath + ".png")
            im = im.filter(ImageFilter.GaussianBlur(radius=2))
            im.save(bpy.context.scene.render.filepath + ".png")
        
        return {'FINISHED'}

class RenderCollectionOperator(bpy.types.Operator):
    bl_idname = "object.rendercollection"
    bl_label = "Render Collection"

    @classmethod
    def poll(cls, context):
        return context.collection.name.startswith("Active") or context.collection.name.startswith("Neutral")

    def execute(self, context):
        active_collection = context.collection
        root_collection = [c for c in bpy.data.collections if c.user_of_id(active_collection)][0]

        for building_collection in bpy.data.collections:
            building_collection.hide_render = True

        active_collection.hide_render = False
        root_collection.hide_render = False
        for building_collection in active_collection.children:
            parent_name = ""

            if (active_collection.name.startswith("Active")):
                parent_name = "Active"
            else:
                parent_name = "Neutral"

            bpy.context.scene.render.filepath = '{0}\{1}\{2}\S_{3}'.format(buildings_output_dir, root_collection.name, parent_name, building_collection.name)
            renderSingleBuilding(context, building_collection)

            if context.scene.hooligans_tool.render_z_bool:
                bpy.context.scene.render.filepath = '{0}\{1}\{2}\SZ_{3}'.format(buildings_output_dir, root_collection.name, parent_name, building_collection.name)
                renderZ(context, building_collection)
                from PIL import Image, ImageFilter
                im = Image.open(bpy.context.scene.render.filepath + ".png")
                im = im.filter(ImageFilter.GaussianBlur(radius=2))
                im.save(bpy.context.scene.render.filepath + ".png")
            
            building_collection.hide_render = True
            
        return {'FINISHED'}

def renderSingleTile(collection):
    collection.hide_render = False
    bpy.ops.render.render(write_still = 1)

def createAtlas(context, files, atlas_name, atlas_size_x, atlas_size_y):
    from PIL import Image

    x = atlas_size_x
    y = atlas_size_y

    image_list = []

    for filename in files:
        im = Image.open(filename + ".png")
        image_list.append(im)

    new_image = Image.new('RGBA', (x, y))

    offset_x = 0
    offset_y = 0

    #TODO pass integer instead of float
    for im in image_list:
        if offset_x >= x:
            offset_x = 0
            offset_y += int(y/16)
        
        new_image.paste(im, (offset_x, offset_y))
        offset_x += int(x/8)
    
    atlas_save_file_path = '{0}\{1}.png'.format(atlas_output_dir, atlas_name)
    new_image.save(atlas_save_file_path) 
    if context.scene.hooligans_tool.show_atlas_bool:
        new_image.show()
    

class RenderSingleTileOperator(bpy.types.Operator):
    bl_idname = "object.rendersingletile"
    bl_label = "RenderSingleTile"

    def execute(self, context):
        collection = context.collection
        for c in bpy.data.collections:
            c.hide_render = True

       
        parent_collection = [c for c in bpy.data.collections if c.user_of_id(collection)][0]
        parent_collection.hide_render = False
        parent_name = parent_collection.name
            
        camera = context.scene.camera
        camera_controller = [obj for obj in parent_collection.objects if obj.name.startswith('CC')][0]

        x = camera_controller.dimensions.x
        y = camera_controller.dimensions.y * 0.5 
        d = max(x, y)

        ppu_option = context.scene.hooligans_tool.ppu_enum

        pixelUnitSize = getPixelUnitSize(ppu_option)
        
        res_x = int(x / pixelUnitSize)
        res_y = int(y / pixelUnitSize)
        
        camera.data.ortho_scale = d

        tree = context.scene.node_tree
        mask_node = [n for n in tree.nodes if n.name == 'Mask'][0]

        
        if ppu_option == 'OP1':
            mask_node.image = bpy.data.images['mask_96x48.psd']
            atlas_size_x = 96 * 8
            atlas_size_y = 48 * 16
        elif ppu_option == 'OP2':
            mask_node.image = bpy.data.images['mask_128x64.psd']
            atlas_size_x = 128 * 8
            atlas_size_y = 64 * 16
        elif ppu_option == 'OP3':
            mask_node.image = bpy.data.images['mask_192x96.psd']
            atlas_size_x = 192 * 8
            atlas_size_y = 96 * 16
        else:
            mask_node.image = bpy.data.images['mask_256x128.psd']
            atlas_size_x = 256 * 8
            atlas_size_y = 128 * 16

         
        bpy.context.scene.render.resolution_x = closestNumber(res_x, 4)
        bpy.context.scene.render.resolution_y = closestNumber(res_y, 4)

        bpy.context.scene.render.filepath = '{0}\{1}'.format(tileSprite_output_dir, collection.name[2:])
        renderSingleTile(collection)
        return {'FINISHED'}


class RenderTileAtlassOperator(bpy.types.Operator):
    bl_idname = "object.rendertileatlass"
    bl_label = "RenderTileAtlass"

    def execute(self, context):
        for c in bpy.data.collections:
            c.hide_render = True

        collection = context.collection
        collection.hide_render = False

        camera = context.scene.camera
        camera_controller = [obj for obj in collection.objects if obj.name.startswith('CC')][0]
        
        file_paths = []

        x = camera_controller.dimensions.x
        y = camera_controller.dimensions.y * 0.5 
        d = max(x, y)

        ppu_option = context.scene.hooligans_tool.ppu_enum

        pixelUnitSize = getPixelUnitSize(ppu_option)
        
        res_x = int(x / pixelUnitSize)
        res_y = int(y / pixelUnitSize)
        
        camera.data.ortho_scale = d

        tree = context.scene.node_tree
        mask_node = [n for n in tree.nodes if n.name == 'Mask'][0]

        atlas_size_x = 0
        atlas_size_y = 0
        atlas_name = ''

        if ppu_option == 'OP1':
            mask_node.image = bpy.data.images['mask_96x48.psd']
            atlas_size_x = 96 * 8
            atlas_size_y = 48 * 16
            atlas_name = '96x48'
        elif ppu_option == 'OP2':
            mask_node.image = bpy.data.images['mask_128x64.psd']
            atlas_size_x = 128 * 8
            atlas_size_y = 64 * 16
            atlas_name = '128x64'
        elif ppu_option == 'OP3':
            mask_node.image = bpy.data.images['mask_192x96.psd']
            atlas_size_x = 192 * 8
            atlas_size_y = 96 * 16
            atlas_name = '192x96'
        else:
            mask_node.image = bpy.data.images['mask_256x128.psd']
            atlas_size_x = 256 * 8
            atlas_size_y = 128 * 16
            atlas_name = '256x128'

         
        bpy.context.scene.render.resolution_x = closestNumber(res_x, 4)
        bpy.context.scene.render.resolution_y = closestNumber(res_y, 4)
        for c in collection.children:

            file_path = '{0}\{1}'.format(tileSprite_output_dir, c.name[2:])
            file_paths.append(file_path)

            bpy.context.scene.render.filepath = file_path
            renderSingleTile(c)
            c.hide_render = True
            
        createAtlas(context, file_paths, collection.name + atlas_name, atlas_size_x, atlas_size_y)    
        #im = Image.open(file_path + ".png")
        #im.show()
        return {'FINISHED'}


class HOOL_PT_Panel(bpy.types.Panel):
    bl_label = "Hooligans Tools"
    bl_idname = "HOOL_PT_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Hooligans"

    def draw(self, context):
        layout = self.layout.column()
        scene = context.scene
        hooligans_tool = scene.hooligans_tool

        row = layout.row()
        row.prop(hooligans_tool, "ppu_enum")
        row.prop(hooligans_tool, "render_z_bool")
        row = layout.row()
        row.operator("object.rendersinglebuilding")
        row = layout.row()
        row.operator("object.renderz")
        row = layout.row()
        row.operator("object.rendercollection")
        row = layout.row()
        row.operator("object.setcamerabounds")
        row = layout.row()
        row.operator("object.rendersingletile")
        row = layout.row()
        row.prop(hooligans_tool, "show_atlas_bool")
        row.operator("object.rendertileatlass")
        #row.prop(hooligans_tool, "ppu_enum")


class Properties(bpy.types.PropertyGroup):
    ppu_enum: bpy.props.EnumProperty(
        name = "PPU",
        description = "Pixels Pre Unit",
        items = [
            ('OP1', "48",  ""),
            ('OP2', "64",  ""),
            ('OP3', "96",  ""),
            ('OP4', "128", "")
        ]
    )

    show_atlas_bool : bpy.props.BoolProperty(
        name = "Show Atlas",
        description = "Show atlas after it renders",
        default = False
    )

    render_z_bool : bpy.props.BoolProperty(
        name = "Render Z",
        description = "Render Z position for upgrade effect",
        default = False
    )


def register():
    from bpy.utils import register_class
    register_class(HOOL_PT_Panel)
    register_class(RenderZOperator)
    register_class(RenderSingleBuildingOperator)
    register_class(RenderCollectionOperator)
    register_class(SetCameraBoundsOperator)
    register_class(RenderSingleTileOperator)
    register_class(RenderTileAtlassOperator)
    register_class(Properties)
    bpy.types.Scene.hooligans_tool = bpy.props.PointerProperty(type = Properties)
    

def unregister():
    from bpy.utils import unregister_class
    unregister_class(HOOL_PT_Panel)
    unregister_class(RenderZOperator)
    unregister_class(RenderSingleBuildingOperator)
    unregister_class(RenderCollectionOperator)
    unregister_class(SetCameraBoundsOperator)
    unregister_class(RenderSingleTileOperator)
    unregister_class(RenderTileAtlassOperator)
    unregister_class(Properties)

    del bpy.types.Scene.hooligans_tool

    